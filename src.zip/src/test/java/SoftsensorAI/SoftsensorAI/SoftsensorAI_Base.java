package SoftsensorAI.SoftsensorAI;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.time.Duration;
import java.util.Properties;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterClass;
import io.github.bonigarcia.wdm.WebDriverManager;

public class SoftsensorAI_Base {

    protected WebDriver driver;
    protected Properties prop;
    protected Properties loc;
    private static final Logger logger = LogManager.getLogger(SoftsensorAI_Base.class);

    public SoftsensorAI_Base() throws IOException {
        loadProperties();
    }

    private void loadProperties() throws IOException {
        prop = new Properties();
        loc = new Properties();	

        try (InputStream input = getClass().getClassLoader().getResourceAsStream("java/qa/configuration/config.properties");
             InputStream input2 = getClass().getClassLoader().getResourceAsStream("java/qa/configuration/locators.properties")) {

            if (input == null || input2 == null) {
                throw new FileNotFoundException("Properties file not found in classpath.");
            }

            prop.load(input);
            loc.load(input2);
        } catch (IOException e) {
            logger.error("Error loading properties files: " + e.getMessage());
            throw e;
        }
    }

    public WebDriver initBrowserAndOpenApp(String browserName) {
        switch (browserName.toLowerCase()) {
            case "chrome":
                WebDriverManager.chromedriver().setup();
                ChromeOptions chromeOptions = new ChromeOptions();
                chromeOptions.addArguments("--disable-gpu", "--no-sandbox", "--remote-allow-origins=*");
                driver = new ChromeDriver(chromeOptions);
                break;

            case "firefox":
                WebDriverManager.firefoxdriver().setup();
                FirefoxOptions firefoxOptions = new FirefoxOptions();
                driver = new FirefoxDriver(firefoxOptions);
                break;

            case "edge":
                WebDriverManager.edgedriver().setup();
                EdgeOptions edgeOptions = new EdgeOptions();
                driver = new EdgeDriver(edgeOptions);
                break;

            default:
                logger.error("Invalid browser: " + browserName);
                throw new IllegalArgumentException("Unsupported browser: " + browserName);
        }

        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        return driver;
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            try {
                driver.quit();
                logger.info("Browser closed successfully.");
            } catch (Exception e) {
                logger.error("Error closing the browser: " + e.getMessage());
            }
        }
    }
}
